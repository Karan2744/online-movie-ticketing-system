import './index.css';

const Header = (props) => {
    return (
        <>
            <header>Movie Ticket Booking</header>
            <div className="subHeading">The best of entertainment for you</div>
        </>
    )
};

export default Header;